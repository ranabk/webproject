<?php 
 // create constants to store non repeating values
                    define('SITEURL' , 'http://localhost/webproject/');
                    $conn = mysqli_connect('localhost', 'root' , '') ;//or die (mysqli_error()); // database connection
                    $db_select = mysqli_select_db($conn , 'PetWeb'); //or die (mysqli_error()); // selecting database 
    //Autharixation control
    //Check wether the user is logged in or not
    if(!isset($_SESSION['user'])){// add session user in login 
    	//user is not logged in
    	//Redirect to login page with message
    	$_SESSION['no-login-message'] = "<div class = 'error'>Please login to acess pages</div>";
    	//redirect to login page
    	header('location:'.SITEURL.'ManagerLoginSHAHAD.php');


    }


?>