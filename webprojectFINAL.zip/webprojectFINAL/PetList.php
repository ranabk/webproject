<!DOCTYPE html>
<?php

            // create constants to store non repeating values
            define('SITEURL' , 'http://localhost/webprojectFINAL/');
            $conn = mysqli_connect('localhost', 'root' , '') ;//or die (mysqli_error()); // database connection
            $db_select = mysqli_select_db($conn , 'PetWeb'); //or die (mysqli_error()); // selecting database
            	$msg='';
	
	if(isset($_GET['delete'])){
		$sql = mysqli_query($conn, "DELETE FROM `pets` WHERE `ID` ='$_GET[delete]'");
			
		if(isset($sql)){
			$msg = '<div class="alert alert-success" role="alert"> Successfully deleted</div>';
		}
	}
	
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Pet List</title>
     <!--font-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <style >
       
        
       body{
        
           font-family: 'Poppins' , sans-serif;
           overflow: scroll;
       }
       .buttompage{
           background-image: url(pics-rana/petdoc.jpeg) ;
           background-position: right;
           background-position-y: bottom;
           background-repeat: no-repeat;
           background-size: 32%;
       }
       .headerbar{
          width: 90% ;
          padding:0 5%;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .logo{
          width: 100px;
          
        }
        .headerbar ul{
            list-style: none;
            display: flex;

        }
        .headerbar ul li{
            margin: 0 15px;
            border-bottom: 2px solid #009688 ;
            position: relative;

        }
        .headerbar ul li a{
          text-decoration:  none;
          color: grey;  
          position:relative;
          transition: all 0.3s;
        }

        .headerbar ul li a:hover{
          color: black;
          transition: 0.2s;
          padding: 0px;
        } 
        .dropdown{
            display: none;
        }
        .headerbar ul li:hover .dropdown {
          display: block;
          position: absolute;
          left: 0;
          top: 100%;
          background-color:#009688;
          font-size: 11px;

        }
        .dropdown ul li a{
            color: white;
        }
        .dropdown ul{
          display: block; /* Display the dropdown */
         
        }


         .headbar ul li.dropdown{
             display: block;
         }
        .menu-rana{
          width: 90% ;
          margin:auto;
          padding: auto;
          padding: 25px ;
          display: flex;
          align-items: center;
          justify-content: space-between;
       }
       
        .menu-rana ul li{
          list-style: none;
          align-items: center;
          display: inline-block;
          margin: 0 15px;
          position:relative;
        }
        .menu-rana ul li a{
          text-decoration:  none;
          color: grey;  
          position:relative;
        }
        .menu-rana li a:hover{
           color: black;
           transition: 0.2s;
           border-bottom: 2px solid #009688;
        }

        table{
            width: 70%;
        }
        .styled-table {

            border-collapse: collapse;
            border-radius: 25px;
            margin: 25px 0;
            font-size: 1.5em;
            font-family: sans-serif;
            min-width: 1100px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
          }
          .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
          }
          .styled-table th, .styled-table td {
              padding: 12px 15px;
          }
          
          .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
          }
          
          .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
          }
          
          .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
          }
        th{
            font-size: 18px;
            color:  #009688;
            text-align: center;
        }
        td{
            text-align: center;
        }

        #cancel{
            color: red;
            font-size: 34.5px;
        }

        .status{
            color: gray;
            text-align:center;
            position: relative;
            padding: 1px;
        }
       
       .starrating{
            user-select: none;
        }
       .rating{
           transform: rotateY(180deg)
       }
        .rating input{
            display: none;
        }
        .rating label{
            font-size: 50px;
            color: lightgrey;
            padding: 1px;
            float: center;
            transition: all 0.2s ease;
        }
        input:not(:checked) ~ label:hover , input:not(:checked) ~ label:hover ~ label{
            color: yellow;
        }
        input:checked ~label{
            color: yellow;
        }
        input #star1:checked ~ label{
            color: #fe7;
            text-shadow: 0 0 20px #952;
        }
        .material-icons{
            font-size: 40px;
            font-weight: 900;
        }
        form header{
            width: 100%;
            font-size: 18px;
            color: gray;
            transition: all 0.2s ease;
        }
        #star1:checked ~ form header:before{
            content: "I don't like it";
        }
        
     textarea{
         background-color: #a9dad441;
         color: #171f1e;
         border: none;
         font-size: 1.25rem;
         box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
         outline: none;
         text-align: center;
         overflow: hidden;

     }
     .submit{
         color: #009688 ;
         font-size: 1.25rem;
         background: transparent;
         border: solid #0096877e;
         border-radius: 3em;
         padding-right: 10px;
         padding-left: 10px;  
         cursor: pointer;    
    
    } 
    .text{
        font-size: 20px;
        color: #666;
        font-weight: 500;

    }
    
    .post{
        display: none;
    }
    
        footer {
          text-align: center;
          font-family: serif;
          padding: 3px;
          background-color: #D9CBB9;
          color: white;
          }

        h2{
            margin: 17px 20px;
            color: #0F4C81 ;
        }

        .footerContent p{
            color: #0F4C81 ;
        }

        .sm{ width: 170px; }
       
      </style>
</head>

<body>

   <div class="headerbar">
            <img src= "pics-rana/Templogo.jpeg" class="logo">
            <ul>
                <li> <a href="PetList.php">  My Pets </a></li>
                <li> <a href="#"> Appointments</a> 
                    <div class="dropdown">
                        <ul > 
                            <li><a href="petOwnerApptRana.php">My Appointments </a> </li>
                            <li><a href="RequestApptHind.php"> Request a new Appointment</a> </li>
                        </ul>
                    </div>
                    
                </li>
                 <li> <a href="AboutUsPageRana.php"> About Us </a> </li>
                <li><a href="#contact us"> Contact Us </a></li>
                <li><a href="#" ><img src = "pics-rana/menu.jpeg" width = "30" height = "10" alt = "menu"></a>
                    <div class="dropdown">
                        <ul >
                            <li><a href="EditProfileReema2.php">Manage Profile</a></li>
                            <li><a href="logout.php">Logout</a></li>
                         </ul>
                    </div>
                </li>
           </ul>
          </div>
   <br><br>

    <hr style= " position: relative; margin-top: 0px; top: -30px; bottom: -10;">
    <div class="buttompage">
    <h1 id="ListPets" class ="listP" style="color:#009688  ; "> <em>List Of Pets:</em>
     <a style="position: absolute; left: 220px; top: 180px; " href="AddPet.php"><img src="pics-leen/add2.png" width="40" height="40"></a></h1>
	 
     <table class="styled-table">
            <tr>
                <th>Pet Pic</th>
                <th>Pet Name</th>
                <th></th>
            </tr>
   
		<?php
		    echo $msg;
			$query ="SELECT * FROM Pets";
		    $sql = mysqli_query($conn , $query);
			$num = 1;
            if($sql == TRUE){
    $SN= 1;
     //count rows to check whether we have data already stored in db
     $count = mysqli_num_rows($sql); // function to get all rows in db
      //check number of rows 
     if($count>0){
			while($rows = mysqli_fetch_assoc($sql)){

                $pic = $rows['Avatar'];
                $name = $rows['Name'];
                $id = $rows['ID'];

                ?>
                <tr>
                    <td><img style="height: 50px; width: 50px; border-radius: 50px;" src="pics-leen/Pets/<?php echo $pic ;?>"></td>
                    <td><?php echo $name?></td>
                    <td>
                        <?php
                        $po = "SELECT ID FROM petowner";
                        $result3 = mysqli_query($conn,$po) ;

                        while($rows = $result3 -> fetch_assoc()){
                        $ownerid = $rows['ID'];}
                        ?>
                        <a href="petInfo.php?petid=<?php echo $id;?>"><img src="pics-leen/view4.png" width="30" height="30" alt="edit" ></a>
                        <a href="petInfo.php?petid=<?php echo $id;?>"><img src="pics-leen/edit.png" width="30" height="30" alt="edit" ></a>
                         <a href="<?php echo SITEURL; ?>deletePet.php?ID=<?php echo $id; ?>"><img src="pics-leen/delete.jpeg" width="30" height="30" alt="delete" ></a>
                    </td>
				</tr>
			<?php				
			$num++;
			

        }
        
       }

     
     else{ ?>
      <td colspan="8"> <?php echo "There are no current pets" ;?> </td> <?php }

     }
		?>
    </table>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    </div>

         <footer>

        <div class="footerContent">
       
        <h2 id="Contact"> Find us at </h2>
        <p> Saudi Arabia, Riyadh </p>
        <p> Anas bin malik </p>
        <p> Building 7  </p>
        <p> 2nd floor  </p>
        <br>
        <p> Call us +966 502909802  </p>
        <p id= "contact us"> To contact us via email <a href="mailto:vet@gmail.com"> click the link </a> and it will direct you. </p>
        <br>
        <img src="pics-shahad/sm.png" class="sm">

        </div>
  </footer>  

</body>
</html>