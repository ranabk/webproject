function validateForm() {
var picture = document.getElementById('myFile').value;
    var name = document.getElementById('petName').value;
    var birthdate = document.getElementById('birthday').value;
    var gender = document.getElementById('gender').value;
    var bread = document.getElementById('bread').value;
    var status = document.getElementById('status').value;
    var vaccine = document.getElementById('vaccine').value;
    var medHistory = document.getElementById('medHistory').value;

    document.window.location = '/'

}