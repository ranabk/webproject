<!DOCTYPE html>
<?php 
	include_once("Config.php");
	$msg='';

	?>
<html>
<head>
    <meta charset="utf-8">
    <title>Services</title>
     <!--font-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <style >
       
        body{
           
            font-family: 'Poppins' , sans-serif;
            overflow: scroll;
        }
        .buttompage{
            background-image: url(pics-rana/petdoc.jpeg) ;
            background-position: right;
            background-position-y: bottom;
            background-repeat: no-repeat;
            background-size: 38%;
            width: 100%;
            height: 50vh;

           
        }
       
        .headerbar{
          width: 90% ;
          padding:0 5%;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .logo{
          width: 100px;
          
        }
        .headerbar ul{
            list-style: none;
            display: flex;

        }
        .headerbar ul li{
            margin: 0 15px;
            border-bottom: 2px solid #009688 ;
            position: relative;

        }
        .headerbar ul li a{
          text-decoration:  none;
          color: grey;  
          position:relative;
          transition: all 0.3s;
        }

        .headerbar ul li a:hover{
          color: black;
          transition: 0.2s;
          padding: 0px;
        } 
        .dropdown{
            display: none;
        }
        .headerbar ul li:hover .dropdown {
          display: block;
          position: absolute;
          left: 0;
          top: 100%;
          background-color:#009688;
          font-size: 11px;

        }
        .dropdown ul li a{
            color: white;
        }
        .dropdown ul{
          display: block; /* Display the dropdown */
         
        }
 
           
        .menu-rana{
          width: 90% ;
          margin:auto;
          padding: auto;
          padding: 25px ;
          display: flex;
          align-items: center;
          justify-content: space-between;
       }
       
        .menu-rana ul li{
          list-style: none;
          align-items: center;
          display: inline-block;
          margin: 0 15px;
          position:relative;
        }
        .menu-rana ul li a{
          text-decoration:  none;
          color: grey;  
          position:relative;
        }
        .menu-rana li a:hover{
           color: black;
           transition: 0.2s;
           border-bottom: 2px solid #009688;
        }

        .newappt, #req  {
            text-align:right;
            width: 50%;
            margin-left: 100px;
            position: relative;
            border-style: solid;
            border-radius: 25px;
            border-width: 2px;
            padding: 35px;
            border-color:rgb(163, 162, 162);
            justify-content: space-between;
            box-shadow: 5px 5px rgb(218, 216, 216);
        }

        .sec{
           
        }


       
       
        .newappt ul li {
            list-style: none;
            display: inline-block;
            margin: 0 7px;
            padding-left: 60;
        }
        .newappt ul li .info{
            text-align: left;
            position:absolute;
            top: 15px;
            left: 40px;
        }
         .newappt ul li .info2{
            text-align: left;
            position:absolute;
            top: 182px;
            left: 40px;
        }

        .kitt{
            position: absolute;
            border-radius: 50%;
            width: 30%;

        }

        .first .kitt{
            margin-left: 170%;
            margin-top: 5px;
           
        }

        .bath{
            position: absolute;
            border-radius: 50%;
            width: 35%;
        }

        .sec .bath{
            margin-left: 195%;
            margin-top: 2%;
        }

        .newappt .sec{
            margin-left: 100%;
        }

        .sertitle{
            margin-left: 80px;
        }
        .styled-table {

          border-collapse: collapse;
          border-radius: 25px;
          margin: 25px 0;
          font-size: 1.5em;
          font-family: sans-serif;
          min-width: 1100px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
          background-color: #009879;
          color: #ffffff;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        
        .styled-table tbody tr {
          border-bottom: 1px solid #dddddd;
        }
        
        .styled-table tbody tr:nth-of-type(even) {
          background-color: #f3f3f3;
        }
        
        .styled-table tbody tr:last-of-type {
          border-bottom: 2px solid #009879;
        }
      th{
          font-size: 18px;
          color:  #009688;
          text-align: center;
      }
      td{
          text-align: center;
      }


       footer {
          text-align: center;
          background-color: ;
          color: white;
          background-color:  #D9CBB9;
        }

        footer h2{
            margin: 17px 20px;
            color: #0F4C81 ;
        }

       .footerContent p{
            color: #0F4C81 ;
           margin: 0 ;
           padding: 0 ;
           font-family: 'Poppins' , sans-serif;
        }

        .sm{ width: 170px; }

        #seappt{
            margin-top: ;
        }
     
       
      </style>
</head>

<body>

    <div class="headerbar">
        <img src= "pics-rana/Templogo.jpeg" class="logo">
        <ul>
          <li> <a href="#"> Appointments</a> 
                    <div class="dropdown">
                        <ul > 
                            <li><a href="manager'sApptpageRana.php">My Appointments </a> </li>
                            <li><a href="RequestedApptHind.php"> Requested Appointments</a> </li>
                        </ul>
                    </div>
          <li><a href="Services.php"> Services </a></li>
          <li> <a href="Manager'sAboutUsPageRana.php"> About Us </a> </li>
          <li><a href="#contact us"> Contact Us </a></li>
                <li><a href="#" ><img src = "pics-rana/menu.jpeg" width = "30" height = "10" alt = "menu"></a>
                    <div class="dropdown">
                        <ul >
                            <li><a href="logout.php">Logout</a></li>
                         </ul>
                    </div>
                </li>
      </div>
      
   <br><br><br>

    <hr style= " position: relative; margin-top: 0px; top: -30px; bottom: -10;">
    <br>
    <div class="buttompage">
    <h1 class ="sertitle"id="Services" style="color:#009688 ; "> <em>Services</em>
        <a style="position: absolute; left: 250px; top: 240px;" href="addService.php"><img src="pics-leen/add2.png" width="40" height="40"></a></h1>
   <?php echo $msg;?>
    <table class="styled-table">
            <tr>
                <th>ID</th>
                <th>Pet Picture</th>
                <th>Pet Name</th>
                <th>Description</th>
                <th>Price</th>
                <th></th>
            </tr>
         <?php

// create constants to store non repeating values
define('SITEURL' , 'http://localhost/webprojectFINAL/');
$conn = mysqli_connect('localhost', 'root' , '') ;//or die (mysqli_error()); // database connection
$db_select = mysqli_select_db($conn , 'PetWeb'); //or die (mysqli_error()); // selecting database 
 // query to get all upcoming appts
 $sql= "SELECT * FROM Services";
 //execute the query
 $res = mysqli_query($conn, $sql);
 
 //check whether the query is executed
 if($res == TRUE){
    $SN= 1;
     //count rows to check whether we have data already stored in db
     $count = mysqli_num_rows($res); // function to get all rows in db
      //check number of rows 
     if($count>0){
         
         //we have data in db
         while($rows=mysqli_fetch_assoc($res)){
             //using while loop to get all data from db
             //get indivisual data
             $id= $rows['ID'];
             $pic = $rows['Image'];
             $petName = $rows['Name'];
             $description = $rows['Description'];
             $price = $rows['Price'];


             //display values in our table
             ?>
              <tr>
                   <td><?php echo $SN++?></td>
                   <td><img style="height: 40px; width: 40px; border-radius: 150px" src="<?php echo $pic; ?>"></td>
                   <td><?php echo $petName;?></td>
                   <td><?php echo $description;?></td>
                   <td><?php echo $price;?></td>
                   <td>
                 <a href="<?php echo SITEURL; ?>deleteSer.php?ID=<?php echo $id; ?>"><img src="pics-leen/delete.jpeg" width="30" height="30" alt="delete" ></a>

                 </td>
             </tr>
             <?php
        }
        
       }

     
     else{ ?>
      <td colspan="8"> <?php echo "There are no services" ;?> </td> <?php }

     }
     ?>
</table>
     

    <br><br><br><br><br>

</div>

 <footer>
	
        <div class="footerContent">
       
			<h2 id="Contact"> Find us at </h2>
			<p> Saudi Arabia, Riyadh </p>
			<p> Anas bin malik </p>
			<p> Building 7  </p>
			<p> 2nd floor  </p>
			<br>
			<p> Call us +966 502909802  </p>
			<p id= "contact us"> To contact us via email <a href="mailto:vet@gmail.com"> click the link </a> and it will direct you. </p>
			<br>
        <img src="pics-shahad/sm.png" class="sm">

        </div>
  </footer>  
   
   

</body>
</html>