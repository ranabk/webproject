<?php
        session_start();
         // create constants to store non repeating values
                    define('SITEURL' , 'http://localhost/webproject/');
                    $conn = mysqli_connect('localhost', 'root' , '') ;//or die (mysqli_error()); // database connection
                    $db_select = mysqli_select_db($conn , 'PetWeb'); //or die (mysqli_error()); // selecting database 
        ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit About Us</title>
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
.headerbar{
          width: 90%  ;
          margin: auto;
          padding: 36px 0;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .logo{
          width: 100px;
          
        }
        .headerbar ul li{
          list-style: none;
          display: inline-block;
          margin: 0 15px;
          position: relative;


        }
        .headerbar ul li a{
          text-decoration:  none;
          color: grey;  
          position:relative;

        }
        .headerbar ul li::after {
          content: '';
          height: 3px;
          width: 100% ;
          background: #009688;
          position: absolute;
          left: 0;
          bottom: -10px;
          transition: 0.5s;
        }
            .headerbar ul li a:hover{
          color: black;
          transition: 0.2s;
          padding: 0px;
     } 
     ul li ul.dropdown {
        position: relative;
        min-width: 200%; /* Set width of the dropdown */
        background: black;
        display: none;
        position: absolute;
        z-index: 999;
        left: 0px;
        padding: 0px; 
        text-decoration: none;
        margin-right: 10px;
       
    }
    ul li:hover ul.dropdown {
        display: block; /* Display the dropdown */
        left: 0px;
         padding: 0px ;
     }

          body{font-family: 'Poppins' , sans-serif;}

          .headbar ul li.dropdown{
            display: block;
          }
    h1{
    font-size: 3rem;
    color: #009688;
    margin-left: 0.5em;
}
.textarea{
background-color: #a9dad441;
color: #171f1e;
border: none;
font-size: 1.25em;
box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
outline: none;
height: fit-content;
  
}

.container{
    margin: 1em;
    position: relative;
    margin-left: 1 em;

    
}


.myborder1{
    position: absolute;
    border-width: 0.55em;
    border-radius: 2em;
    border-color: #458B8442;
    border-style: solid;
   width: 70em;
   padding: 50px 20px;

   
}
.content-section .card img{
    width: 20%;
    height: auto;
}
    .changes{
    color: #009688;
    margin-left: 10em;
    border-radius: 30px;
            font-weight: bold;
            background: #458B8442;
            padding: 10px 20px;
            text-decoration: none;
            margin-bottom: 60px;

}

button.changes {
  cursor: pointer;
  border:none;
}

button.changes:hover{
  background-color:#009688;
  color: #fff;
}

  .dropdown ul li a{
            color: white;
        }
        .dropdown ul{
          display: block; /* Display the dropdown */
  }

  .popup{
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    transition: 150ms ease-in-out;
    border: 3px solid rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    z-index: 10;
    background-color: #fff;
    width: 500px;
    max-width: 80%;
  }

  .popup.active{
    transform: translate(-50%, -50%) scale(1);
  }

  .popup img{
    display: block;
    margin: 0 auto;
    max-width: 70%;
  }

  .popup-header{
    text-align: center;
    font-weight: bolder;
    font-size: 1.25rem;
  }

  .popup-description{
    text-align: center;
  }

  .popup button{
    display: block;
    width:100px;
    height: 60px;
    margin: 20px auto;
  }

#overlay{
  position: fixed;
  opacity: 0;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  transition: 150ms ease-in-out;
  background-color: rgba(0, 0, 0, 0.5);
  pointer-events: none;
}

#overlay.active{
  opacity: 1;
  pointer-events: all;

}

.adding{
  position: relative;
  margin-top: 50px;
  margin-bottom: 100px;
  padding-top:100em;
  margin-left: 600px;
}


</style>
</head>
<body>
  <div class="headerbar">
        <img src= "pic-reema/Templogo.jpeg" class="logo">
        <ul>
          <li> <a href="AvailableApptRana.php"> Appointments  </a> </li>
           <li><a href ="Services.php"> Services </a></li>
          <li> <a href="Manager'sAboutUsPageRana.php"> About Us </a> </li>
          <li><a href="#contact us"> Contact Us </a></li>
         


          <li>    <a href="#" ><img src = "pic-reema/menuIcon.png" width = "30" height = "10" alt = "menu"> </a>
            <ul class="dropdown">
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </ul>
    </li>
</ul>
      </div>

<h1 style=" color: #009688"> Edit About Us </h1>
 <?php
 /*
     define('LOCALHOST','192.168.100.66');
     define('DB_USERNAME','reemaalsaliem');
     define('DB_PASSWORD','Rreema123');
     define('DB_NAME','PetWeb');*/
     $conn =mysqli_connect('localhost','root','');
     $db_select =mysqli_select_db($conn,'PetWeb');
     $sql= "SELECT * FROM AboutUs";
 
    
     $result= mysqli_query($conn,$sql);
     if($result==true)
      $rows=mysqli_fetch_assoc($result)
          ?>
<hr> </hr>
<br><br>
<div class="container">
<div class="myborder1">
  <?php
                    // query to get aboutus
                    $sql  = "SELECT * FROM AboutUs";
                     //execute the query
                    $res = mysqli_query($conn, $sql);
                    if($res == TRUE){
                     //count rows to check whether we have data already stored in db
                     $count = mysqli_num_rows($res);
                     while($rows=mysqli_fetch_assoc($res))
                        $AboutUs = $rows['AboutUs'];}?>
<form class="textarea" action="" method="POST">
  <label style=" color: #009688">About Us:</label><br>
  <textarea id="textarea1" name="newAboutUs"  rows="10" cols="50">
  <?php echo $AboutUs; ?>
  </textarea><br>
  <label style=" color: #009688">Change background</label><br>
    <input name="newbg" type="file" > 

        <div class="content-section">


<?php 
// if(isset($_POST['Submit']))
// (
// $AboutUs = $_POST['newAboutUs'];
// $background = $_POST['newbg'];
$aboutError=$picError= '';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if ( isset ($_POST['submit'])){
  if (empty($_POST["newAboutUs"])){
    $serviceError = "About Us is required";}
    else {$a =$_POST["newAboutUs"];}

    if (empty($_POST["newbg"])) {
      $passError = "pic is required";}
      else {$p =$_POST["newbg"];}

      $sql = " UPDATE AboutUs SET
AboutUs = '$a', Background = '$p'";

}
 } 




?>
        </form>
<form class="whatwedo">
     <div class="card">
    
                    <?php 
                                $sql= "SELECT * FROM WhatWeDo";
                                 //execute the query
                                 $res = mysqli_query($conn, $sql);
                                 if($res == TRUE){
                                 //count rows to check whether we have data already stored in db
                                 $count = mysqli_num_rows($res); // function to get all rows in db

                                 //check number of rows 
                                 if($count >0){
                        
                                 //we have data in db
                                 while($rows=mysqli_fetch_assoc($res)){
                                 //using while loop to get all data from db
                                 //get indivisual data
                                 $pic = $rows['pic'];
                                 $service = $rows['Service'];
                                 $discription = $rows['Description'];
                            ?>

                             <div class="card">
                                <ul style="list-style: none">
                                    <li>
                            <img style="height: 300px; width: 300px; border-radius: 150px" src="pics-rana/<?php echo $pic; ?>"> 
                             <input name="newpic" type="file"> <br> </li>
                            <li><textarea style=" color: #009688" class="servicename" name="uptser"><?php echo $service ;?></textarea></li>
                            <li><textarea class="disccription" rows="10" cols="25" name="uptdes"><?php echo $discription ;?></textarea></li>
                              </div>
<?php
        }

?>
              </div>            
            </div>  
      
            
            </div>   
               <?php }
               } ?>

            
     <div class="adding">
      <form action="" method="POST"> 
  <label for="changeImage">Add service</label><br>
  <textarea name= "newserv"id="newservice" rows="2" cols="50"></textarea><br>
  <label>Add image </label><br>
  <input name="addImage" type="file"><br>
  <label>Add Description</label> <br>
  <textarea name= "adddes" id="description" rows="10" cols="50"></textarea>
</form></div>
<?php
$serviceError=$picError=$decError= '';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if ( isset ($_POST['submit'])){
  if ($_POST["newserv"] == 'none'){
    $serviceError = "service is required";}
    else {$s =$_POST["newserv"];}

    if (empty($_POST["addImage"])) {
      $picError = "pic is required";}
      else {$p =$_POST["addImage"];}

    if (empty($_POST["adddes"])) {
      $decError = "Description is required";}
      else {$d =$_POST["adddes"];}

      $sql="INSERT INTO WhatWeDo SET pic='$p', Service='$s', Description='$d'";

  
   /*define('LOCALHOST','localhost');
  define('DB_USERNAME','root');
  define('DB_PASSWORD','');
  define('DB_NAME','mypet'); */
  $conn =mysqli_connect('localhost','root','') or die(mysqli_error()); //edit info later
  $db_select =mysqli_select_db($conn,'PetWeb') or die(mysqli_error());//edit info later
$result =mysqli_query($conn,$sql) or die(mysqli_error()); 
 if ($result==true){
   $_SESSION['request']="About Us Updated successfully!"; 
}
else{
  $_SESSION['request']="About Us Update failed!";
  header('location:'.SITEURL."Manager'sAboutUsPageRana.php");
  }
    }
}
  

 
  ?>

   </form>

<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if ( isset ($_POST['submit'])){
  if (empty($_POST["newpic"] == 'null')){
    $picError = "pic is required";}
    else {$p =$_POST["newpic"];}

    if (empty($_POST["uptser"])) {
      $servError = "service is required";}
      else {$s =$_POST["uptser"];}

    if (empty($_POST["uptdes"])) {
      $desError = "Description is required";}
      else {$d =$_POST["uptdes"];}

      $sql="UPDATE WhatWeDo SET pic='$p', Service='$s',
  Description='$d' WHERE ID=$id ";
  $res = mysqli_query($conn,$sql);

   define('SITEURL','http://localhost/webprojectFINAL/');
  /*define('LOCALHOST','localhost');
  define('DB_USERNAME','root');
  define('DB_PASSWORD','');
  define('DB_NAME','mypet'); */
  $conn =mysqli_connect('localhost','root','') or die(mysqli_error()); //edit info later
  $db_select =mysqli_select_db($conn,'PetWeb') or die(mysqli_error());//edit info later
$result =mysqli_query($conn,$sql) or die(mysqli_error()); 
 if ($result==true){
   $_SESSION['request']="Profile Updated successfully!"; //request or add only?
   header('location:'.SITEURL."Manager'sAboutUsPageRana.php");
}
else{
  $_SESSION['request']="Profile Update failed!";
  header('location:'.SITEURL."Manager'sAboutUsPageRana.php");
  }
  } }
  ?>








  <br><br>
  <div>
    <button class="changes" onclick="openPopUp()" name= "submit">Save Changes</button>
  
 </span> </a>
  </div>
</div>
</div>

<div class="popup" id="popup">
  <div class="popup-body">
    <div class="tick"><img src="pic-reema/tick.jpg" alt="tick"></div>
    <div class="popup-header">Changes Saved!</div>
    <p class="popup-description">The changes have been saved and "About Us" is updated.</p>
    <br>
    <button class="changes" onclick="closePopUp()">Close</button>
  </div>
</div>

<div id="overlay"></div>

<script src="editAboutUsReema.js"></script>
</body> 
</html>