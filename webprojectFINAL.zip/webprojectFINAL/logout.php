<?php 
session_start();
include "db_conn.php";
$sql = "UPDATE petowner SET logged = '0'";
$result2 = mysqli_query($conn , $sql);

session_unset();


session_destroy();

header("Location: main2SHAHAD.php");